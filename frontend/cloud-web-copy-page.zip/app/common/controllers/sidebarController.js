(function(namespace, undefined) {
	'use strict';

	var SidebarController = ['$scope', '$http', '$stateParams',  'cssInjector','$location',
		function($scope, $http, $stateParams, cssInjector, $location) {

			//Sidebar functions



		}
	];
	angular.module('Shared').controller('SidebarCtrl', SidebarController);

})(this);
