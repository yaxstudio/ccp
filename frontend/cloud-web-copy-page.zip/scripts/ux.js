
function ExecuteLoaders(){
/* TypeKit
**********************/
try{
    Typekit.load();
    $('span[aria-hidden]').remove();
}catch(e){

}

/* Set the Animations at Scroll
**********************/


}









